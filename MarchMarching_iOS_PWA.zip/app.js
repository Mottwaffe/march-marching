
let steps=Number(localStorage.steps||0);
const s=document.getElementById('steps');
const c=document.getElementById('clicks');
const m=document.getElementById('march');
const u=document.getElementById('unlocks');

function render(){
 s.textContent=steps+' Steps';
 c.textContent=steps;
 let unlocks=['Default Outfit ✅'];
 if(steps>=100) unlocks.push('Dreamy Parade 🎀');
 if(steps>=500) unlocks.push('Winter Cozy ❄️');
 if(steps>=1000) unlocks.push('Fumo Friend 🧸');
 u.innerHTML=unlocks.join('<br>');
}
render();

document.getElementById('marchBtn').onclick=()=>{
 steps++;
 localStorage.steps=steps;
 m.style.transform='translateX(8px) scale(1.08)';
 setTimeout(()=>m.style.transform='translateX(0) scale(1)',120);
 render();
};

if('serviceWorker' in navigator){
 navigator.serviceWorker.register('sw.js');
}
